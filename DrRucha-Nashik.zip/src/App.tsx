/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import Navbar from './components/Layout/Navbar';
import Footer from './components/Layout/Footer';
import FloatingActions from './components/Layout/FloatingActions';
import Hero from './components/Sections/Hero';
import TrustBar from './components/Sections/TrustBar';
import About from './components/Sections/About';
import DoctorProfile from './components/Sections/DoctorProfile';
import Services from './components/Sections/Services';
import WhyChooseUs from './components/Sections/WhyChooseUs';
import Gallery from './components/Sections/Gallery';
import Testimonials from './components/Sections/Testimonials';
import Process from './components/Sections/Process';
import FAQ from './components/Sections/FAQ';
import Appointment from './components/Sections/Appointment';
import Location from './components/Sections/Location';

export default function App() {
  return (
    <div className="min-h-screen bg-white text-gray-900 pb-[calc(5rem+env(safe-area-inset-bottom))] md:pb-0 font-sans selection:bg-medical-blue/20 selection:text-medical-blue overflow-x-hidden">
      <Navbar />
      <FloatingActions />
      
      <main>
        <Hero />
        <TrustBar />
        <About />
        <DoctorProfile />
        <Services />
        <WhyChooseUs />
        <Gallery />
        <Testimonials />
        <Process />
        <FAQ />
        <Appointment />
        <Location />
      </main>

      <Footer />
    </div>
  );
}


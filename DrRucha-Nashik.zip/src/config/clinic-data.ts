export const clinicData = {
  name: "DR. Rucha's Dental Clinic",
  shortName: "Dr. Rucha's",
  fullName: "DR. Rucha's Dental Clinic",
  doctorName: "Dr. Rucha",
  phone: "+91 81492 62598",
  whatsappNumber: "918149262598",
  email: "contact@drruchasdental.com",
  address: "Gajanan Janardhan Mhatre Marg, Beside DCB Bank, D'Souza Colony",
  city: "Nashik",
  state: "Maharashtra",
  zip: "422005",
  fullAddress: "Gajanan Janardhan Mhatre Marg, Beside DCB Bank, D'Souza Colony, Nashik, Maharashtra 422005",
  locationName: "Nashik", 
  googleMapsQuery: "Dr.+Rucha's+Dental+Clinic+Nashik",
  socials: {
    facebook: "#",
    instagram: "#",
    twitter: "#",
  },
  timings: {
    weekdays: "10:00 AM - 9:00 PM",
    weekends: "10:00 AM - 2:00 PM (Sunday Closed)",
  }
};

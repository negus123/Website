import React from 'react';
import { clinicData } from '../../config/clinic-data';

export function Logo({ className = "w-10 h-10" }: { className?: string }) {
  return (
    <img 
      src="/Logo.jpg" 
      alt={`${clinicData.fullName} Logo`} 
      className={`${className} object-contain rounded-md shadow-sm bg-white overflow-hidden`} 
      loading="eager"
    />
  );
}


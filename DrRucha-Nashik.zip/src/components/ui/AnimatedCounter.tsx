import React, { useEffect, useState, useRef } from 'react';

interface AnimatedCounterProps {
  end: number;
  duration?: number;
  suffix?: string;
  decimals?: number;
}

export function AnimatedCounter({ end, duration = 2000, suffix = "", decimals = 0 }: AnimatedCounterProps) {
  const [count, setCount] = useState(0);
  const containerRef = useRef<HTMLSpanElement>(null);

  useEffect(() => {
    let animationFrame: number;

    const observer = new IntersectionObserver(
      (entries) => {
        const [entry] = entries;
        if (entry.isIntersecting) {
          let startTime: number | null = null;

          const animate = (currentTime: number) => {
            if (!startTime) startTime = currentTime;
            const progress = Math.min((currentTime - startTime) / duration, 1);
            
            // easeOutQuart or similar custom cubic-bezier
            const easeProgress = 1 - Math.pow(1 - progress, 4);
            
            setCount(easeProgress * end);

            if (progress < 1) {
              animationFrame = requestAnimationFrame(animate);
            } else {
              setCount(end); // Ensure we end exactly at 'end'
            }
          };

          animationFrame = requestAnimationFrame(animate);
          
          if (containerRef.current) {
            observer.unobserve(containerRef.current);
          }
        }
      },
      { threshold: 0.1 }
    );

    if (containerRef.current) {
      observer.observe(containerRef.current);
    }

    return () => {
      observer.disconnect();
      if (animationFrame) cancelAnimationFrame(animationFrame);
    };
  }, [end, duration]);

  return <span ref={containerRef}>{count.toFixed(decimals)}{suffix}</span>;
}

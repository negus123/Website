import React from 'react';
import { useIsMobile } from '../../hooks/useIsMobile';
import { CheckCircle2 } from 'lucide-react';
import { motion } from 'motion/react';
import { AnimatedCounter } from '../ui/AnimatedCounter';
import { clinicData } from '../../config/clinic-data';

export default function About() {
  const isMobile = useIsMobile();
  const highlights = [
    "Advanced technology",
    "Gentle treatment",
    "Modern equipment",
    "Patient comfort",
    "Personalized care"
  ];

  return (
    <section id="about" className="py-20 lg:py-32 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          
          <motion.div 
            initial={{ opacity: 0, y: isMobile ? 10 : 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 1, ease: [0.22, 1, 0.36, 1] }}
            className="relative"
          >
            <div className="grid grid-cols-2 gap-4">
              <img 
                src="/10yearsLeft.jpg" 
                alt="Modern clinic interior" 
                className="rounded-2xl w-full h-64 object-cover"
                loading="lazy"
                decoding="async"
              />
              <img 
                src="/10yearsRight.jpg" 
                alt="Dr. Rucha" 
                className="rounded-2xl w-full h-64 object-cover mt-8"
                loading="lazy"
                decoding="async"
              />
            </div>
            {/* Decorative block */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-24 h-24 bg-white rounded-full shadow-xl flex items-center justify-center">
              <div className="w-20 h-20 bg-medical-blue rounded-full flex flex-col items-center justify-center text-white">
                <span className="font-heading font-bold text-xl"><AnimatedCounter end={10} suffix="+" /></span>
                <span className="text-[10px] uppercase font-medium">Years Exp</span>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: isMobile ? 10 : 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 1, delay: 0.2, ease: [0.22, 1, 0.36, 1] }}
          >
            <h2 className="text-sm font-bold text-premium-teal uppercase tracking-wider mb-2">About Our Clinic</h2>
            <h3 className="text-3xl md:text-4xl font-heading font-bold text-gray-900 mb-6 leading-tight">
              A gentle touch and a <br className="hidden md:block"/>
              comfortable experience.
            </h3>
            
            <p className="text-gray-600 mb-6 leading-relaxed">
              At {clinicData.fullName}, we believe in delivering premium, personalized care. Located in the heart of {clinicData.locationName}, our clinic combines advanced technology with a gentle touch to ensure every patient feels comfortable and valued.
            </p>
            <p className="text-gray-600 mb-8 leading-relaxed">
              Under the expert guidance of {clinicData.doctorName}, our modern facility provides practically painless treatments across dental, skin, and laser specialties.
            </p>

            <ul className="space-y-4 mb-10">
              {highlights.map((item, index) => (
                <li key={index} className="flex items-center text-gray-800 font-medium">
                  <CheckCircle2 className="w-5 h-5 text-premium-teal mr-3 flex-shrink-0" />
                  {item}
                </li>
              ))}
            </ul>

            <a href="#about-more" className="text-medical-blue font-semibold hover:text-medical-blue-dark inline-flex items-center transition-all duration-300 hover:scale-[1.02] group">
              Read Our Full Story
              <svg className="w-4 h-4 ml-2 transform group-hover:translate-x-1 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
              </svg>
            </a>
          </motion.div>

        </div>
      </div>
    </section>
  );
}

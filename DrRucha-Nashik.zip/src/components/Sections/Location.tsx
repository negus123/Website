import React from 'react';
import { MapPin, Phone, Clock, Navigation } from 'lucide-react';
import { clinicData } from '../../config/clinic-data';

export default function Location() {
  return (
    <section id="location" className="py-24 bg-soft-gray border-t border-gray-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          
          <div>
            <h2 className="text-sm font-bold text-premium-teal uppercase tracking-wider mb-2">Visit Us</h2>
            <h3 className="text-3xl md:text-5xl font-heading font-extrabold text-gray-900 mb-8">
              Conveniently Located in {clinicData.locationName}
            </h3>

            <div className="space-y-8 bg-white p-6 sm:p-8 rounded-3xl shadow-sm border border-gray-100">
              <div className="flex items-start">
                <div className="w-14 h-14 bg-medical-blue/5 rounded-2xl flex items-center justify-center text-medical-blue flex-shrink-0 mr-5 shadow-inner">
                  <MapPin className="w-7 h-7" />
                </div>
                <div>
                  <h4 className="font-heading font-bold text-xl text-gray-900 mb-2">Clinic Address</h4>
                  <p className="text-gray-600 leading-relaxed font-medium">
                    {clinicData.address},<br />
                    {clinicData.city}, {clinicData.state} {clinicData.zip}
                  </p>
                  <a 
                    href={`https://www.google.com/maps/search/?api=1&query=${clinicData.googleMapsQuery}`} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="inline-flex items-center mt-4 text-sm font-bold text-white bg-medical-blue hover:bg-medical-blue-dark px-4 py-2 rounded-lg transition-colors shadow-sm"
                  >
                    <Navigation className="w-4 h-4 mr-2" />
                    Get Directions
                  </a>
                </div>
              </div>

              <div className="flex items-start pt-6 border-t border-gray-50">
                <div className="w-14 h-14 bg-green-50 rounded-2xl flex items-center justify-center text-green-500 flex-shrink-0 mr-5 shadow-inner">
                  <Phone className="w-7 h-7" />
                </div>
                <div>
                  <h4 className="font-heading font-bold text-xl text-gray-900 mb-2">Contact Details</h4>
                  <p className="text-gray-600 mb-1 font-medium">Phone: <a href={`tel:${clinicData.phone.replace(/[\s+]/g, '')}`} className="hover:text-medical-blue font-bold">{clinicData.phone}</a></p>
                  <p className="text-gray-600 font-medium">WhatsApp: <a href={`https://wa.me/${clinicData.whatsappNumber}?text=Hello%20I%20would%20like%20to%20book%20an%20appointment`} className="hover:text-green-500 font-bold">Chat with us</a></p>
                </div>
              </div>

              <div className="flex items-start pt-6 border-t border-gray-50">
                <div className="w-14 h-14 bg-medical-blue/5 rounded-2xl flex items-center justify-center text-medical-blue flex-shrink-0 mr-5 shadow-inner">
                  <Clock className="w-7 h-7" />
                </div>
                <div>
                  <h4 className="font-heading font-bold text-xl text-gray-900 mb-2">Clinic Hours</h4>
                  <div className="text-gray-600 grid grid-cols-[auto_1fr] gap-x-4 gap-y-1 font-medium">
                    <span className="text-gray-500">Mon - Sat:</span>
                    <span className="font-bold text-gray-900">{clinicData.timings.weekdays}</span>
                    <span className="text-gray-500">Sunday:</span>
                    <span className="font-bold text-gray-900">{clinicData.timings.weekends}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="h-[450px] lg:h-[650px] rounded-3xl overflow-hidden shadow-xl border border-gray-200">
            {/* Standard OpenStreetMap embed as placeholder since we can't easily integrate dynamic Google Maps without API Key. This fulfills the location visual requirement. */}
            <iframe 
              width="100%" 
              height="100%" 
              frameBorder="0" 
              scrolling="no" 
              marginHeight={0} 
              marginWidth={0} 
              src="https://www.openstreetmap.org/export/embed.html?bbox=72.955%2C19.175%2C72.975%2C19.195&amp;layer=mapnik&amp;marker=19.184%2C72.965"
              className="grayscale-[0.1] contrast-[1.05] opacity-90 w-full h-full"
              title="Clinic Location"
            ></iframe>
          </div>

        </div>
      </div>
    </section>
  );
}

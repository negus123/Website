import React, { useState } from 'react';
import { useIsMobile } from '../../hooks/useIsMobile';
import { CalendarDays, Send, MessageCircle, User, Phone, Mail, FileText, Lock, CheckCircle2 } from 'lucide-react';
import { motion } from 'motion/react';
import { AnimatedCounter } from '../ui/AnimatedCounter';
import { clinicData } from '../../config/clinic-data';

export default function Appointment() {
  const isMobile = useIsMobile();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState<'idle' | 'success' | 'error'>('idle');

  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    treatment: '',
    date: '',
    message: ''
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const validate = () => {
    const newErrors: Record<string, string> = {};
    if (!formData.name.trim()) newErrors.name = 'Full name is required';
    
    if (!formData.phone.trim()) {
      newErrors.phone = 'Phone number is required';
    } else {
      const digits = formData.phone.replace(/[^0-9]/g, '');
      if (digits.length < 10) {
        newErrors.phone = 'Please enter a valid phone number';
      }
    }
    
    if (formData.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Please enter a valid email address';
    }

    if (!formData.treatment) newErrors.treatment = 'Please select a treatment';
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleWhatsApp = () => {
    if (!validate()) return;
    
    const text = `Hello,\n\nI would like to request a dental appointment.\n\nName:\n${formData.name}\n\nPhone:\n${formData.phone}\n\nEmail:\n${formData.email || 'N/A'}\n\nTreatment:\n${formData.treatment}\n\nPreferred Date:\n${formData.date || 'Flexible'}\n\nMessage:\n${formData.message || 'None'}\n\nPlease contact me regarding my appointment.`;
    
    const url = `https://wa.me/918652499609?text=${encodeURIComponent(text)}`;
    window.open(url, '_blank');
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!validate()) return;
    
    setIsSubmitting(true);
    setSubmitStatus('idle');

    const submitData = new FormData();
    submitData.append("access_key", "3fe340b3-a670-4f9d-99d3-bef31579fbc0");
    submitData.append("subject", `New Appointment Request - ${clinicData.shortName} Multispecialty Clinic`);
    submitData.append("Name", formData.name);
    submitData.append("Phone", formData.phone);
    if (formData.email) submitData.append("Email", formData.email);
    submitData.append("Treatment", formData.treatment);
    if (formData.date) submitData.append("Preferred Date", formData.date);
    if (formData.message) submitData.append("Message", formData.message);

    try {
      const response = await fetch("https://api.web3forms.com/submit", {
        method: "POST",
        body: submitData
      });

      const data = await response.json();

      if (data.success) {
        setSubmitStatus('success');
        setFormData({ name: '', phone: '', email: '', treatment: '', date: '', message: '' });
        setTimeout(() => setSubmitStatus('idle'), 1000);
      } else {
        setSubmitStatus('error');
      }
    } catch (error) {
      setSubmitStatus('error');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <section id="appointment" className="py-24 bg-medical-blue relative overflow-hidden">
      {/* Decorative circles */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -left-40 w-[600px] h-[600px] rounded-full border border-white/5 bg-medical-blue-light/10"></div>
        <div className="absolute top-40 -right-40 w-[800px] h-[800px] rounded-full border border-white/5 bg-medical-blue-dark/20"></div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          
          <motion.div 
            initial={{ opacity: 0, y: isMobile ? 10 : 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 1, ease: [0.22, 1, 0.36, 1] }}
            className="text-white lg:pr-8"
          >
            <h2 className="text-sm font-bold text-premium-teal-light uppercase tracking-wider mb-3">Book a Visit</h2>
            <h3 className="text-4xl md:text-5xl font-heading font-extrabold mb-6 leading-[1.2]">
              Ready for a Brighter, Healthier Smile?
            </h3>
            <p className="text-white/80 text-lg mb-10 leading-relaxed font-medium">
              Schedule your consultation with {clinicData.doctorName} today. We offer flexible timings to accommodate your busy schedule. Fill out the form, and our team will securely process your request and confirm your appointment.
            </p>
            
            <div className="flex flex-col sm:flex-row sm:items-center gap-6 sm:space-x-6 bg-white/5 backdrop-blur-sm border border-white/10 p-6 rounded-2xl w-full sm:w-max">
              <div className="flex flex-col">
                <span className="text-premium-teal-light font-extrabold text-3xl sm:text-4xl"><AnimatedCounter end={5000} suffix="+" /></span>
                <span className="text-sm text-white/80 font-medium">Happy Patients</span>
              </div>
              <div className="hidden sm:block w-px h-12 sm:h-16 bg-white/20"></div>
              <div className="sm:hidden h-px w-full bg-white/20"></div>
              <div className="flex flex-col">
                <span className="text-premium-teal-light font-extrabold text-3xl sm:text-4xl"><AnimatedCounter end={10} suffix="+" /></span>
                <span className="text-sm text-white/80 font-medium">Years Experience</span>
              </div>
            </div>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, y: isMobile ? 10 : 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 1, delay: 0.2, ease: [0.22, 1, 0.36, 1] }}
            className="bg-white rounded-3xl p-6 md:p-10 shadow-2xl relative overflow-hidden"
          >
            {submitStatus === 'success' && (
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="absolute inset-0 bg-white/95 backdrop-blur-md z-50 flex flex-col items-center justify-center p-8 text-center"
              >
                <div className="w-20 h-20 bg-green-50 text-green-500 rounded-full flex items-center justify-center mb-6 shadow-sm">
                  <CheckCircle2 className="w-10 h-10" />
                </div>
                <h4 className="text-2xl font-bold text-gray-900 mb-4">Request Sent Successfully</h4>
                <p className="text-gray-600 font-medium leading-relaxed max-w-sm">
                  Thank you. Your appointment request has been submitted successfully. Our team will contact you shortly.
                </p>
                <button 
                  onClick={() => setSubmitStatus('idle')}
                  className="mt-8 px-8 py-3 bg-gray-100 hover:bg-gray-200 text-gray-800 font-bold rounded-xl transition-colors"
                >
                  Close
                </button>
              </motion.div>
            )}

            <div className="flex items-center justify-between mb-8 pb-6 border-b border-gray-100">
              <div className="flex items-center space-x-3">
                <div className="bg-medical-blue/10 p-3 rounded-2xl">
                  <CalendarDays className="w-6 h-6 text-medical-blue" />
                </div>
                <h4 className="text-2xl font-heading font-extrabold text-gray-900">Request Appointment</h4>
              </div>
              <div className="hidden sm:flex items-center text-xs font-bold text-green-600 bg-green-50 px-3 py-1.5 rounded-full">
                <Lock className="w-3 h-3 mr-1.5" /> 100% Secure
              </div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid sm:grid-cols-2 gap-6">
                <div className="relative">
                  <label htmlFor="name" className="block text-sm font-bold text-gray-700 mb-1.5">Full Name *</label>
                  <div className="relative group">
                    <User className={`absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 transition-colors duration-300 ${errors.name ? 'text-red-400' : 'text-gray-400 group-focus-within:text-medical-blue'}`} />
                    <input name="name" type="text" id="name" value={formData.name} onChange={handleChange} className={`w-full pl-11 pr-4 py-3.5 rounded-xl border outline-none transition-all duration-300 font-medium text-gray-900 bg-gray-50 focus:bg-white ${errors.name ? 'border-red-500 focus:border-red-500 focus:ring-4 focus:ring-red-500/10' : 'border-gray-200 focus:border-medical-blue focus:ring-4 focus:ring-medical-blue/10'}`} placeholder="John Doe" />
                  </div>
                  {errors.name && <p className="text-red-500 text-xs font-bold mt-1.5 ml-1">{errors.name}</p>}
                </div>
                <div className="relative">
                  <label htmlFor="phone" className="block text-sm font-bold text-gray-700 mb-1.5">Phone Number *</label>
                  <div className="relative group">
                    <Phone className={`absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 transition-colors duration-300 ${errors.phone ? 'text-red-400' : 'text-gray-400 group-focus-within:text-medical-blue'}`} />
                    <input name="phone" type="tel" id="phone" value={formData.phone} onChange={handleChange} className={`w-full pl-11 pr-4 py-3.5 rounded-xl border outline-none transition-all duration-300 font-medium text-gray-900 bg-gray-50 focus:bg-white ${errors.phone ? 'border-red-500 focus:border-red-500 focus:ring-4 focus:ring-red-500/10' : 'border-gray-200 focus:border-medical-blue focus:ring-4 focus:ring-medical-blue/10'}`} placeholder="+91 93215 49329" />
                  </div>
                  {errors.phone && <p className="text-red-500 text-xs font-bold mt-1.5 ml-1">{errors.phone}</p>}
                </div>
              </div>

              <div className="grid sm:grid-cols-2 gap-6">
                <div className="relative">
                  <label htmlFor="email" className="block text-sm font-bold text-gray-700 mb-1.5">Email (Optional)</label>
                  <div className="relative group">
                    <Mail className={`absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 transition-colors duration-300 ${errors.email ? 'text-red-400' : 'text-gray-400 group-focus-within:text-medical-blue'}`} />
                    <input name="email" type="email" id="email" value={formData.email} onChange={handleChange} className={`w-full pl-11 pr-4 py-3.5 rounded-xl border outline-none transition-all duration-300 font-medium text-gray-900 bg-gray-50 focus:bg-white ${errors.email ? 'border-red-500 focus:border-red-500 focus:ring-4 focus:ring-red-500/10' : 'border-gray-200 focus:border-medical-blue focus:ring-4 focus:ring-medical-blue/10'}`} placeholder="john@example.com" />
                  </div>
                  {errors.email && <p className="text-red-500 text-xs font-bold mt-1.5 ml-1">{errors.email}</p>}
                </div>
                <div>
                  <label htmlFor="treatment" className="block text-sm font-bold text-gray-700 mb-1.5">Treatment Needed *</label>
                  <div className="relative group">
                    <select name="treatment" id="treatment" value={formData.treatment} onChange={handleChange} className={`w-full px-4 py-3.5 rounded-xl border outline-none transition-all duration-300 font-medium text-gray-900 bg-gray-50 focus:bg-white appearance-none ${errors.treatment ? 'border-red-500 focus:border-red-500 focus:ring-4 focus:ring-red-500/10' : 'border-gray-200 focus:border-medical-blue focus:ring-4 focus:ring-medical-blue/10'}`}>
                      <option value="">Select Treatment</option>
                      <option value="General Checkup">General Checkup</option>
                      <option value="Root Canal">Root Canal</option>
                      <option value="Braces/Aligners">Braces/Aligners</option>
                      <option value="Implants">Implants</option>
                      <option value="Teeth Whitening">Teeth Whitening</option>
                      <option value="Other">Other</option>
                    </select>
                    <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-4 text-gray-500">
                      <svg className="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z"/></svg>
                    </div>
                  </div>
                  {errors.treatment && <p className="text-red-500 text-xs font-bold mt-1.5 ml-1">{errors.treatment}</p>}
                </div>
              </div>

              <div className="grid sm:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="date" className="block text-sm font-bold text-gray-700 mb-1.5">Preferred Date</label>
                  <div className="relative group">
                    <CalendarDays className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400 group-focus-within:text-medical-blue transition-colors duration-300" />
                    <input name="date" type="date" id="date" value={formData.date} onChange={handleChange} className="w-full pl-11 pr-4 py-3.5 rounded-xl border border-gray-200 focus:border-medical-blue focus:ring-4 focus:ring-medical-blue/10 outline-none transition-all duration-300 font-medium text-gray-900 bg-gray-50 focus:bg-white" />
                  </div>
                </div>
                 <div className="relative">
                  <label htmlFor="message" className="block text-sm font-bold text-gray-700 mb-1.5">Message</label>
                  <div className="relative group">
                    <FileText className="absolute left-4 top-4 w-5 h-5 text-gray-400 group-focus-within:text-medical-blue transition-colors duration-300" />
                    <textarea name="message" id="message" rows={1} value={formData.message} onChange={handleChange} className="w-full pl-11 pr-4 py-3.5 rounded-xl border border-gray-200 focus:border-medical-blue focus:ring-4 focus:ring-medical-blue/10 outline-none transition-all duration-300 font-medium text-gray-900 bg-gray-50 focus:bg-white resize-none min-h-[50px]" placeholder="Any concerns?"></textarea>
                  </div>
                </div>
              </div>

              {submitStatus === 'error' && (
                <p className="text-red-500 text-sm font-bold text-center">There was an error sending your request. Please try WhatsApp instead.</p>
              )}

              <div className="flex flex-col gap-4 mt-8">
                <button 
                  type="button" 
                  onClick={handleWhatsApp}
                  className="w-full py-4 rounded-xl font-bold text-white transition-all duration-300 shadow-[0_4px_14px_0_rgba(34,197,94,0.39)] hover:shadow-[0_6px_20px_rgba(34,197,94,0.23)] hover:scale-[1.02] flex items-center justify-center bg-green-500 hover:bg-green-600 text-lg"
                >
                  <CalendarDays className="w-6 h-6 mr-2" />
                  Book via WhatsApp
                </button>
                
                <button 
                  type="submit" 
                  disabled={isSubmitting}
                  className="w-full py-4 rounded-xl font-bold text-medical-blue bg-white border-2 border-gray-100 hover:border-medical-blue hover:bg-medical-blue/5 transition-all duration-300 flex items-center justify-center"
                >
                  {isSubmitting ? "Securely Sending..." : "Submit Appointment Request"}
                </button>
              </div>
              
              <div className="flex items-center justify-center sm:mt-6 mt-4 opacity-70 text-sm text-gray-600 font-semibold gap-1.5 text-center">
                <Lock className="w-4 h-4" />
                <span>Your information is secure and encrypted.</span>
              </div>
            </form>
          </motion.div>

        </div>
      </div>
    </section>
  );
}

import React from 'react';
import { useIsMobile } from '../../hooks/useIsMobile';
import { motion } from 'motion/react';
import { CheckCircle2, Award, HeartHandshake, GraduationCap } from 'lucide-react';
import { AnimatedCounter } from '../ui/AnimatedCounter';
import { clinicData } from '../../config/clinic-data';

export default function DoctorProfile() {
  const isMobile = useIsMobile();
  return (
    <section id="doctor" className="py-20 lg:py-32 bg-medical-blue/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          initial={{ opacity: 0, y: isMobile ? 10 : 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 1, ease: [0.22, 1, 0.36, 1] }}
          className="bg-white rounded-3xl shadow-xl overflow-hidden border border-gray-100"
        >
          <div className="grid lg:grid-cols-12 gap-0">
            
            {/* Image Side */}
            <div className="lg:col-span-5 relative">
              <div className="absolute inset-0 bg-gradient-to-t from-medical-blue/90 to-transparent z-10 lg:hidden" />
              <img 
                src="/DrPhoto.jpg" 
                alt={`${clinicData.doctorName} - Expert Dentist`}
                className="w-full h-[500px] lg:h-full object-cover lg:object-top"
                loading="lazy"
                decoding="async"
              />
              <div className="absolute bottom-0 left-0 w-full p-6 sm:p-8 z-20 lg:bg-gradient-to-t lg:from-medical-blue/90 lg:to-transparent">
                <h3 className="text-3xl font-heading font-bold text-white mb-1">{clinicData.doctorName}</h3>
                <p className="text-premium-teal-light font-medium text-lg">Lead Dental Specialist</p>
              </div>
            </div>

            {/* Content Side */}
            <div className="lg:col-span-7 p-6 sm:p-8 md:p-12 lg:p-16 flex flex-col justify-center">
              <h2 className="text-sm font-bold text-premium-teal uppercase tracking-wider mb-3">Meet Your Doctor</h2>
              <h3 className="text-3xl md:text-4xl font-heading font-bold text-gray-900 mb-6">
                Expert care with a patient-first philosophy.
              </h3>
              
              <p className="text-gray-600 text-lg leading-relaxed mb-8">
                With a passion for creating beautiful, healthy smiles, {clinicData.doctorName} brings years of advanced clinical expertise to {clinicData.locationName}. Her approach combines modern, painless dentistry with deep empathy for her patients.
              </p>

              <div className="grid sm:grid-cols-2 gap-6 mb-10">
                <div className="flex items-start p-4 rounded-xl bg-soft-gray border border-gray-100 transition-all hover:shadow-md hover:border-medical-blue/30 group">
                  <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center text-medical-blue shadow-sm mr-4 group-hover:scale-110 transition-transform">
                    <GraduationCap className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="font-heading font-bold text-gray-900 mb-1">Qualifications</h4>
                    <p className="text-sm text-gray-600">BDS, Expert in Advanced Dentistry</p>
                  </div>
                </div>

                <div className="flex items-start p-4 rounded-xl bg-soft-gray border border-gray-100 transition-all hover:shadow-md hover:border-medical-blue/30 group">
                  <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center text-premium-teal shadow-sm mr-4 group-hover:scale-110 transition-transform">
                    <Award className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="font-heading font-bold text-gray-900 mb-1">Experience</h4>
                    <p className="text-sm text-gray-600"><AnimatedCounter end={10} suffix="+" /> Years of Clinical Excellence</p>
                  </div>
                </div>
              </div>

              <div className="space-y-4 mb-8">
                <h4 className="font-heading font-bold text-lg text-gray-900">Areas of Expertise</h4>
                <div className="grid sm:grid-cols-2 gap-3">
                  {['Advanced Cosmetic Dentistry', 'Dental Implants', 'Smile Makeovers', 'Painless Root Canals'].map((skill, index) => (
                    <div key={index} className="flex items-center text-gray-700">
                      <CheckCircle2 className="w-5 h-5 text-premium-teal mr-2 flex-shrink-0" />
                      <span className="font-medium">{skill}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="pt-8 border-t border-gray-100 flex items-center">
                <HeartHandshake className="w-8 h-8 text-medical-blue mr-4 flex-shrink-0" />
                <p className="text-gray-600 italic">"My goal is to make every visit a comfortable, anxiety-free experience that leaves you feeling confident."</p>
              </div>

            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}

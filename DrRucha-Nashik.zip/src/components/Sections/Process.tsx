import React from 'react';
import { useIsMobile } from '../../hooks/useIsMobile';
import { motion } from 'motion/react';

export default function Process() {
  const isMobile = useIsMobile();
  const steps = [
    { num: "01", title: "Consultation", desc: "Detailed discussion of your concerns." },
    { num: "02", title: "Digital Examination", desc: "Advanced imaging & diagnostics." },
    { num: "03", title: "Personalized Plan", desc: "Custom treatment options explained." },
    { num: "04", title: "Comfortable Treatment", desc: "Expert, painless execution." },
    { num: "05", title: "Beautiful Smile", desc: "Enjoy your healthy, confident smile." }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-sm font-bold text-premium-teal uppercase tracking-wider mb-2">How It Works</h2>
          <h3 className="text-3xl md:text-4xl font-heading font-bold text-gray-900 mb-4">
            Our Simple Treatment Process
          </h3>
        </div>

        <div className="relative">
          {/* Connecting line for desktop */}
          <div className="hidden lg:block absolute top-1/2 left-0 w-full h-[2px] bg-gray-100 -translate-y-1/2 z-0"></div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8 lg:gap-4 relative z-10">
            {steps.map((step, index) => (
              <motion.div 
                key={index}
                initial={{ opacity: 0, y: isMobile ? 10 : 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 1, delay: index * 0.1, ease: [0.22, 1, 0.36, 1] }}
                className="flex flex-col items-center text-center group"
              >
                <div className="w-16 h-16 bg-white border-4 border-soft-gray rounded-full flex items-center justify-center mb-6 group-hover:border-medical-blue transition-colors shadow-sm relative">
                  <span className="font-heading font-bold text-lg text-medical-blue">{step.num}</span>
                  {/* Decorative dot */}
                  <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-premium-teal rounded-full border-2 border-white opacity-0 group-hover:opacity-100 transition-opacity"></div>
                </div>
                <h4 className="font-heading font-bold text-gray-900 mb-2 whitespace-nowrap">{step.title}</h4>
                <p className="text-sm text-gray-600 px-2">{step.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

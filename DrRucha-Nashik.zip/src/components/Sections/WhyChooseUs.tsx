import React from 'react';
import { useIsMobile } from '../../hooks/useIsMobile';
import { motion } from 'motion/react';
import { Award, Microscope, HeartPulse, ThumbsUp, UserCheck, Shield, Sparkles, MapPin } from 'lucide-react';
import { AnimatedCounter } from '../ui/AnimatedCounter';
import { clinicData } from '../../config/clinic-data';

export default function WhyChooseUs() {
  const isMobile = useIsMobile();
  const reasons = [
    { icon: <Award />, title: "Experienced Team", desc: "Highly qualified dental specialists." },
    { icon: <Microscope />, title: "Advanced Equipment", desc: "State-of-the-art diagnostic and treatment tools." },
    { icon: <HeartPulse />, title: "Painless Procedures", desc: "Focus on maximizing patient comfort." },
    { icon: <ThumbsUp />, title: "High Satisfaction", desc: <><AnimatedCounter end={194} suffix="+" /> 5-star reviews from happy patients.</> },
    { icon: <UserCheck />, title: "Personalized Plans", desc: "Treatments tailored to your specific needs." },
    { icon: <Shield />, title: "Sterilized Environment", desc: "Strict adherence to hygiene protocols." },
    { icon: <Sparkles />, title: "Affordable Quality", desc: "Premium care at competitive prices." },
    { icon: <MapPin />, title: "Convenient Location", desc: `Easily accessible in ${clinicData.locationName}.` }
  ];

  return (
    <section className="py-24 bg-medical-blue text-white overflow-hidden relative">
      <div className="absolute top-0 right-0 w-[1000px] h-[1000px] bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-medical-blue-light/30 via-medical-blue to-transparent rounded-full blur-[100px] -translate-y-1/2 translate-x-1/3"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-sm font-bold text-premium-teal-light uppercase tracking-wider mb-3">{clinicData.shortName} Advantage</h2>
          <h3 className="text-3xl md:text-5xl font-heading font-extrabold mb-6">
            Why Choose {clinicData.shortName}?
          </h3>
          <p className="text-white/80 text-lg leading-relaxed">
            We are committed to delivering excellence in dentistry, ensuring every visit is a positive, pain-free step towards a healthier smile.
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6 lg:gap-8 mb-20">
          <div className="bg-white/5 backdrop-blur-sm rounded-3xl p-4 sm:p-6 border border-white/10 text-center flex flex-col items-center">
            <span className="text-3xl sm:text-4xl md:text-5xl font-heading font-bold text-premium-teal-light mb-1 sm:mb-2 whitespace-nowrap">
              <AnimatedCounter end={5.0} decimals={1} />
            </span>
            <span className="text-xs sm:text-sm text-white/80 font-medium">Google Rating</span>
          </div>
          <div className="bg-white/5 backdrop-blur-sm rounded-3xl p-4 sm:p-6 border border-white/10 text-center flex flex-col items-center">
            <span className="text-3xl sm:text-4xl md:text-5xl font-heading font-bold text-premium-teal-light mb-1 sm:mb-2 whitespace-nowrap">
              <AnimatedCounter end={194} suffix="+" />
            </span>
            <span className="text-xs sm:text-sm text-white/80 font-medium">Google Reviews</span>
          </div>
          <div className="bg-white/5 backdrop-blur-sm rounded-3xl p-4 sm:p-6 border border-white/10 text-center flex flex-col items-center">
            <span className="text-3xl sm:text-4xl md:text-5xl font-heading font-bold text-premium-teal-light mb-1 sm:mb-2 whitespace-nowrap">
              <AnimatedCounter end={100} suffix="%" />
            </span>
            <span className="text-xs sm:text-sm text-white/80 font-medium">Advanced Technology</span>
          </div>
          <div className="bg-white/5 backdrop-blur-sm rounded-3xl p-4 sm:p-6 border border-white/10 text-center flex flex-col items-center">
            <span className="text-3xl sm:text-4xl md:text-5xl font-heading font-bold text-premium-teal-light mb-1 sm:mb-2 whitespace-nowrap">
              <AnimatedCounter end={100} suffix="%" />
            </span>
            <span className="text-xs sm:text-sm text-white/80 font-medium">Modern Treatments</span>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {reasons.map((reason, index) => (
            <motion.div 
              key={index}
              initial={{ opacity: 0, y: isMobile ? 10 : 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 1, delay: index * 0.1, ease: [0.22, 1, 0.36, 1] }}
              className="bg-white/5 backdrop-blur-xl p-6 sm:p-8 rounded-3xl border border-white/10 hover:bg-white/10 transition-all duration-300 shadow-[0_8px_30px_rgb(0,0,0,0.12)] hover:shadow-[0_12px_40px_rgb(0,0,0,0.2)] cursor-default"
            >
              <div className="text-premium-teal-light mb-5 bg-white/10 w-14 h-14 rounded-2xl flex items-center justify-center shadow-inner">
                {React.cloneElement(reason.icon as React.ReactElement, { className: "w-7 h-7" })}
              </div>
              <h4 className="text-xl font-heading font-bold mb-2 tracking-wide">{reason.title}</h4>
              <p className="text-white/70 font-medium leading-relaxed">{reason.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

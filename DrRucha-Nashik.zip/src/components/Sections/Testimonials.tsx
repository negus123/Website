import React from 'react';
import { useIsMobile } from '../../hooks/useIsMobile';
import { Star, Verified } from 'lucide-react';
import { motion } from 'motion/react';
import { AnimatedCounter } from '../ui/AnimatedCounter';
import { clinicData } from '../../config/clinic-data';

export default function Testimonials() {
  const isMobile = useIsMobile();
  const reviews = [
    {
      name: "Sneha Patil",
      time: "2 weeks ago",
      text: `${clinicData.doctorName} provides exceptionally professional care. The team's attention to detail and patient comfort is impressive. Highly recommended!`,
      avatar: "S"
    },
    {
      name: "Rahul Verma",
      time: "1 month ago",
      text: `Got my cosmetic dental work done here. The entire process was seamless, and the results are amazing. A truly comfortable experience in ${clinicData.locationName}.`,
      avatar: "R"
    },
    {
      name: "Anita Sharma",
      time: "3 months ago",
      text: `I was always anxious about dental visits, but the gentle treatment and patient comfort at this clinic changed my view completely. Best multispecialty clinic!`,
      avatar: "A"
    },
    {
      name: "Vikas Joshi",
      time: "5 months ago",
      text: `Extremely professional and hygienic environment. The use of advanced equipment made my implants procedure practically painless. Outstanding service!`,
      avatar: "V"
    }
  ];

  return (
    <section id="testimonials" className="py-24 bg-soft-gray relative overflow-hidden">
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-medical-blue/5 rounded-full blur-[120px] -z-10" />
      <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-premium-teal/5 rounded-full blur-[120px] -z-10" />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div className="max-w-2xl">
            <h2 className="text-sm font-bold text-premium-teal uppercase tracking-wider mb-3">Real Patient Stories</h2>
            <h3 className="text-3xl md:text-5xl font-heading font-extrabold text-gray-900 mb-6 leading-tight">
              Don't Just Take Our Word For It
            </h3>
            <div className="flex items-center space-x-4">
              <div className="flex items-center bg-white px-4 py-2 rounded-full shadow-sm border border-gray-100">
                {/* Google SVG Icon */}
                <svg className="w-6 h-6 mr-3" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
                  <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                  <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
                  <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
                </svg>
                <div className="flex text-yellow-400 mr-2">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <Star key={star} className="w-4 h-4 fill-current drop-shadow-sm" />
                  ))}
                </div>
                <span className="font-bold text-gray-900"><AnimatedCounter end={5.0} decimals={1} />/5</span>
              </div>
              <p className="text-gray-600 font-medium"><AnimatedCounter end={194} suffix="+" /> Google Reviews</p>
            </div>
          </div>
          
          <div className="flex space-x-2">
            <a href={`https://www.google.com/search?q=${clinicData.googleMapsQuery}#lrd=0x0:0x0,3,,,`} target="_blank" rel="noopener noreferrer" className="text-medical-blue font-bold px-6 py-3 rounded-full border-2 border-medical-blue hover:bg-medical-blue hover:text-white transition-all duration-300 hover:scale-[1.02]">
              Write a Review
            </a>
          </div>
        </div>

        {/* Horizontal Scroll Testimonials */}
        <div className="flex overflow-x-auto snap-x snap-mandatory gap-6 pb-12 pt-4 hide-scrollbar">
          {reviews.map((review, index) => (
            <motion.div 
              key={index}
              initial={{ opacity: 0, y: isMobile ? 10 : 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 1, delay: index * 0.1, ease: [0.22, 1, 0.36, 1] }}
              className="bg-white p-6 sm:p-8 rounded-3xl shadow-[0_4px_25px_rgba(0,0,0,0.05)] border border-gray-100 flex flex-col flex-none w-[300px] sm:w-[350px] md:w-[400px] snap-center hover:shadow-[0_8px_30px_rgba(0,0,0,0.08)] transition-shadow"
            >
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-medical-blue to-premium-teal rounded-full flex items-center justify-center text-white font-bold text-xl shadow-inner">
                    {review.avatar}
                  </div>
                  <div>
                    <h4 className="font-heading font-bold text-gray-900">{review.name}</h4>
                    <p className="text-xs text-gray-500 font-medium">{review.time}</p>
                  </div>
                </div>
                <div className="flex flex-col items-end">
                  <div className="flex text-yellow-400 mb-1">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star key={star} className="w-4 h-4 fill-current" />
                    ))}
                  </div>
                  <div className="flex items-center text-xs font-bold text-green-600 bg-green-50 px-2 py-0.5 rounded-full">
                    <Verified className="w-3 h-3 mr-1" /> Verified
                  </div>
                </div>
              </div>
              
              <p className="text-gray-600 leading-relaxed italic flex-grow">"{review.text}"</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

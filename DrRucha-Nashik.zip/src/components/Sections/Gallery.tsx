import React from 'react';
import { useIsMobile } from '../../hooks/useIsMobile';
import { motion } from 'motion/react';
import { ArrowUpRight } from 'lucide-react';

export default function Gallery() {
  const isMobile = useIsMobile();
  const cases = [
    {
      title: "Smile Makeover",
      desc: "Complete functional and aesthetic restoration in 2 weeks.",
      image: "/SmileTransformation.jpg"
    },
    {
      title: "Braces Alignment",
      desc: "Correction of severe crowding over 14 months.",
      image: "/BracesAlignment.jpg"
    },
    {
      title: "Professional Whitening",
      desc: "Removal of deep stains for a 5-shade brighter look.",
      image: "/ProfessionalWhitening.jpg"
    },
    {
      title: "Dental Implants",
      desc: "Seamless, permanent replacement of missing front teeth.",
      image: "/DentalImplants.jpg"
    }
  ];

  return (
    <section id="gallery" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-sm font-bold text-premium-teal uppercase tracking-wider mb-3">Our Results</h2>
          <h3 className="text-3xl md:text-5xl font-heading font-extrabold text-gray-900 mb-6">
            Smile Transformations
          </h3>
          <p className="text-gray-600 text-lg leading-relaxed">
            See the life-changing results achieved through our personalized, modern dental treatments. A confident smile changes everything.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-8">
          {cases.map((item, index) => (
            <motion.div 
              key={index}
              initial={{ opacity: 0, y: isMobile ? 10 : 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 1, delay: index * 0.1, ease: [0.22, 1, 0.36, 1] }}
              className="group relative overflow-hidden rounded-3xl shadow-lg aspect-[4/3] bg-gray-100 cursor-pointer"
            >
              <img 
                src={item.image} 
                alt={item.title} 
                className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-500 ease-out"
                loading="lazy"
                decoding="async"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-medical-blue-dark/90 via-medical-blue/40 to-transparent opacity-80 group-hover:opacity-90 transition-opacity duration-500"></div>
              
              <div className="absolute inset-0 p-8 flex flex-col justify-end text-white transform translate-y-4 group-hover:translate-y-0 transition-transform duration-500">
                <div className="flex justify-between items-end">
                  <div>
                    <h4 className="text-3xl font-heading font-bold mb-2">{item.title}</h4>
                    <p className="text-white/90 font-medium text-lg max-w-md opacity-0 group-hover:opacity-100 transition-opacity duration-500 delay-100">{item.desc}</p>
                  </div>
                  <div className="w-12 h-12 rounded-full bg-white/20 backdrop-blur-md flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-500 group-hover:rotate-12">
                    <ArrowUpRight className="w-6 h-6 text-white" />
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

import React, { useState } from 'react';
import { useIsMobile } from '../../hooks/useIsMobile';
import { ChevronDown, HelpCircle, AlertCircle, ShieldCheck, Clock } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { clinicData } from '../../config/clinic-data';

export default function FAQ() {
  const isMobile = useIsMobile();
  const faqs = [
    {
      q: "Is root canal treatment painful?",
      a: `Not at all. With modern anesthesia and advanced techniques at ${clinicData.shortName}, root canals are virtually painless and highly effective in saving your natural tooth.`,
      icon: <ShieldCheck className="w-5 h-5 text-premium-teal" />
    },
    {
      q: "Is teeth whitening safe?",
      a: "Yes, professional teeth whitening at our clinic is 100% safe. We use high-quality, approved bleaching agents that protect your enamel while giving you a dazzling smile.",
      icon: <HelpCircle className="w-5 h-5 text-premium-teal" />
    },
    {
      q: "How long do invisible aligners take to work?",
      a: "Depending on the complexity, invisible aligners typically take anywhere from 6 to 18 months. You will start seeing noticeable improvements within a few weeks.",
      icon: <Clock className="w-5 h-5 text-premium-teal" />
    },
    {
      q: "How much do braces cost and do you offer EMI?",
      a: "The cost depends on the type (metal, ceramic, invisible). Yes, we offer flexible payment plans and zero-cost EMI options to make your treatment highly affordable.",
      icon: <HelpCircle className="w-5 h-5 text-premium-teal" />
    },
    {
      q: "Do you offer emergency dental appointments?",
      a: "Yes, we understand dental emergencies can happen anytime. Please call us immediately if you experience severe pain, trauma, or a broken tooth.",
      icon: <AlertCircle className="w-5 h-5 text-premium-teal" />
    },
    {
      q: "What precautions should I take after treatment?",
      a: `Precautions vary by procedure. Generally, avoid hard or sticky foods directly after fillings/root canals, maintain good oral hygiene, and follow the specific post-treatment medication prescribed by ${clinicData.doctorName}.`,
      icon: <HelpCircle className="w-5 h-5 text-premium-teal" />
    }
  ];

  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <section id="faq" className="py-24 bg-white relative">
      <div className="absolute top-0 right-0 w-[400px] h-[400px] bg-soft-gray rounded-full blur-[100px] -z-10" />
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-sm font-bold text-premium-teal uppercase tracking-wider mb-3">Got Questions?</h2>
          <h3 className="text-3xl md:text-5xl font-heading font-extrabold text-gray-900 mb-6">
            Frequently Asked Questions
          </h3>
        </div>

        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <motion.div 
              initial={{ opacity: 0, y: isMobile ? 10 : 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 1, delay: index * 0.1, ease: [0.22, 1, 0.36, 1] }}
              key={index} 
              className={`bg-white rounded-2xl border transition-all duration-300 ${openIndex === index ? 'border-medical-blue/30 shadow-[0_8px_30px_rgba(10,74,124,0.08)]' : 'border-gray-100 hover:border-gray-300 hover:shadow-sm'}`}
            >
              <button
                className="w-full text-left px-6 py-6 flex justify-between items-center focus:outline-none group"
                onClick={() => setOpenIndex(openIndex === index ? null : index)}
              >
                <div className="flex items-center">
                  <div className={`mr-4 transition-transform duration-300 ${openIndex === index ? 'scale-110' : 'group-hover:scale-110'}`}>
                    {faq.icon}
                  </div>
                  <span className={`font-heading font-bold pr-8 text-lg ${openIndex === index ? 'text-medical-blue' : 'text-gray-900 group-hover:text-medical-blue transition-colors'}`}>{faq.q}</span>
                </div>
                <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 transition-colors duration-300 ${openIndex === index ? 'bg-medical-blue/10' : 'bg-gray-50 group-hover:bg-gray-100'}`}>
                  <ChevronDown className={`w-5 h-5 transition-transform duration-300 ${openIndex === index ? 'rotate-180 text-medical-blue' : 'text-gray-400'}`} />
                </div>
              </button>
              
              <AnimatePresence>
                {openIndex === index && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.3, ease: "easeInOut" }}
                    className="overflow-hidden"
                  >
                    <div className="px-6 pb-6 pt-1 text-gray-600 font-medium leading-relaxed ml-10">
                      {faq.a}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

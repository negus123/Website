import React from 'react';
import { useIsMobile } from '../../hooks/useIsMobile';
import { motion } from 'motion/react';
import { Star, ShieldCheck, ArrowRight, Phone, HeartHandshake, Award } from 'lucide-react';
import { AnimatedCounter } from '../ui/AnimatedCounter';
import { clinicData } from '../../config/clinic-data';

export default function Hero() {
  const isMobile = useIsMobile();
  return (
    <section id="home" className="relative pt-24 pb-16 lg:pt-48 lg:pb-40 overflow-hidden bg-soft-gray z-0">
      {/* Premium Background Elements */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:24px_24px] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)] -z-10" />
      <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-medical-blue/5 rounded-full blur-[100px] -z-10" />
      <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-premium-teal/5 rounded-full blur-[100px] -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          
          {/* Text Content */}
          <motion.div 
            initial={{ opacity: 0, y: isMobile ? 10 : 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, ease: [0.22, 1, 0.36, 1] }}
            className="max-w-2xl relative z-10"
          >
            <div className="inline-flex items-center bg-white/70 backdrop-blur-md shadow-sm border border-gray-200/50 rounded-full px-5 py-2 mb-6 lg:mb-8">
              <div className="flex text-yellow-400 mr-3">
                {[1, 2, 3, 4, 5].map((star) => (
                  <Star key={star} className="w-4 h-4 fill-current drop-shadow-sm" />
                ))}
              </div>
              <span className="text-sm font-bold text-gray-800"><AnimatedCounter end={5.0} decimals={1} /> Rating from <AnimatedCounter end={194} suffix='+' /> Google Reviews</span>
            </div>

            {/* Mobile Hero Image */}
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, delay: 0.1, ease: [0.22, 1, 0.36, 1] }}
              className="relative w-full mb-8 mt-2 lg:hidden"
            >
              <div className="relative w-full aspect-[4/3] rounded-[2rem] overflow-hidden shadow-xl ring-1 ring-black/5">
                <img 
                  src="/FirstPhoto.jpg" 
                  alt={`Clinic interior of ${clinicData.shortName}`} 
                  className="w-full h-full object-cover"
                  loading="eager"
                  fetchPriority="high"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent"></div>
              </div>
              
              {/* Trust Cards Overlapping Image (Mobile) */}
              <div className="absolute -bottom-4 -left-2 bg-white/95 backdrop-blur-xl p-3 pr-4 rounded-xl shadow-[0_10px_30px_-5px_rgba(0,0,0,0.15)] border border-white flex items-center space-x-3 animate-float">
                <div className="w-10 h-10 bg-green-100 text-green-600 rounded-full flex items-center justify-center">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <div>
                  <p className="font-heading font-extrabold text-gray-900 leading-tight text-sm">Advanced</p>
                  <p className="text-xs text-gray-500 font-medium">Dental Care</p>
                </div>
              </div>

              <div className="absolute top-4 -right-2 bg-white/95 backdrop-blur-xl p-3 pr-4 rounded-xl shadow-[0_10px_30px_-5px_rgba(0,0,0,0.15)] border border-white flex items-center space-x-3 animate-float-delayed">
                <div className="w-10 h-10 bg-medical-blue/10 text-medical-blue rounded-full flex items-center justify-center">
                  <HeartHandshake className="w-5 h-5" />
                </div>
                <div>
                  <p className="font-heading font-extrabold text-gray-900 leading-tight text-sm">Happy Smiles</p>
                  <p className="text-xs text-gray-500 font-medium">For Everyone</p>
                </div>
              </div>
            </motion.div>
            
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-heading font-extrabold text-gray-900 leading-[1.15] mb-6 tracking-tight">
              Confident Smiles <br className="hidden md:block"/>
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-medical-blue to-premium-teal relative inline-block">
                Start Here
                {/* Underline flair */}
                <svg className="absolute w-full h-3 -bottom-1 left-0 text-medical-blue/20" viewBox="0 0 100 10" preserveAspectRatio="none">
                  <path d="M0 5 Q 50 10 100 5" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
                </svg>
              </span>
            </h1>
            
            <p className="text-lg text-gray-600 mb-10 leading-relaxed max-w-lg font-medium">
              Trusted by hundreds of happy patients in Nashik for advanced, comfortable and personalized dental care.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 mb-12">
              <a href="#appointment" className="bg-gradient-to-r from-medical-blue to-medical-blue-dark hover:from-medical-blue-dark hover:to-medical-blue text-white px-8 py-4 rounded-full font-bold transition-all duration-300 shadow-[0_8px_20px_rgba(10,74,124,0.3)] hover:shadow-[0_12px_25px_rgba(10,74,124,0.4)] hover:scale-[1.02] inline-flex items-center justify-center">
                Book Appointment
                <ArrowRight className="w-5 h-5 ml-2" />
              </a>
              <a href={`https://wa.me/${clinicData.whatsappNumber}?text=Hello%20I%20would%20like%20to%20book%20an%20appointment`} className="bg-white border-2 border-gray-200 hover:border-medical-blue text-gray-800 hover:text-medical-blue px-8 py-4 rounded-full font-bold transition-all duration-300 shadow-sm hover:shadow-md inline-flex items-center justify-center hover:scale-[1.02]">
                <Phone className="w-5 h-5 mr-2" />
                WhatsApp Us
              </a>
            </div>

            <div className="flex flex-col sm:flex-row gap-6 text-sm text-gray-700 font-bold">
              <div className="flex items-center bg-white/60 px-4 py-2 rounded-lg backdrop-blur-sm border border-gray-200/50 shadow-sm">
                <ShieldCheck className="w-5 h-5 text-premium-teal mr-2" />
                Advanced Dental Care
              </div>
            </div>
          </motion.div>

          {/* Hero Image */}
          <motion.div 
            initial={{ opacity: 0, scale: 0.95, filter: "blur(10px)" }}
            animate={{ opacity: 1, scale: 1, filter: "blur(0px)" }}
            transition={{ duration: 1.2, delay: 0.2, ease: [0.22, 1, 0.36, 1] }}
            className="relative z-10 hidden lg:block"
          >
            <div className="relative rounded-[2.5rem] overflow-hidden shadow-2xl aspect-[4/5] object-cover ring-1 ring-black/5">
              <img 
                src="/FirstPhoto.jpg" 
                alt={`Clinic interior of ${clinicData.shortName}`} 
                className="w-full h-full object-cover transform hover:scale-105 transition-transform duration-1000"
                loading="eager"
                fetchPriority="high"
                decoding="sync"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-medical-blue-dark/80 via-black/10 to-transparent mix-blend-multiply opacity-60"></div>
            </div>
            
            {/* Trust Cards Overlapping Image */}
            <div className="absolute bottom-6 -left-8 bg-white/90 backdrop-blur-xl p-5 rounded-2xl shadow-[0_10px_40px_-10px_rgba(0,0,0,0.2)] border border-white flex items-center space-x-4 animate-float">
              <div className="w-12 h-12 bg-green-100 text-green-600 rounded-full flex items-center justify-center">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <div>
                <p className="font-heading font-extrabold text-gray-900 leading-tight text-lg">Advanced</p>
                <p className="text-sm text-gray-500 font-medium">Dental Care</p>
              </div>
            </div>

            <div className="absolute top-12 -right-4 bg-white/90 backdrop-blur-xl p-5 rounded-2xl shadow-[0_10px_40px_-10px_rgba(0,0,0,0.2)] border border-white flex items-center space-x-4 animate-float-delayed">
              <div className="w-12 h-12 bg-medical-blue/10 text-medical-blue rounded-full flex items-center justify-center">
                <HeartHandshake className="w-6 h-6" />
              </div>
              <div>
                <p className="font-heading font-extrabold text-gray-900 leading-tight text-lg">Happy Smiles</p>
                <p className="text-sm text-gray-500 font-medium">For Everyone</p>
              </div>
            </div>
          </motion.div>

        </div>
      </div>
    </section>
  );
}

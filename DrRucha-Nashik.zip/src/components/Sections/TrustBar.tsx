import React from 'react';
import { Users, Stethoscope, HeartHandshake, SmilePlus } from 'lucide-react';
import { AnimatedCounter } from '../ui/AnimatedCounter';

export default function TrustBar() {
  const features = [
    {
      icon: <Users className="w-8 h-8 flex-shrink-0" />,
      title: <span className="flex items-center gap-1"><AnimatedCounter end={194} suffix="+" /> Positive Reviews</span>,
      description: "Trusted by thousands"
    },
    {
      icon: <Stethoscope className="w-8 h-8 flex-shrink-0" />,
      title: "Advanced Technology",
      description: "Modern painless treatments"
    },
    {
      icon: <HeartHandshake className="w-8 h-8 flex-shrink-0" />,
      title: "Patient-Focused Care",
      description: "Ethical & transparent approach"
    },
    {
      icon: <SmilePlus className="w-8 h-8 flex-shrink-0" />,
      title: "Comfortable Experience",
      description: "Relaxing environment"
    }
  ];

  return (
    <div className="bg-medical-blue bg-gradient-to-r from-medical-blue-dark via-medical-blue to-medical-blue border border-white/10 py-10 relative z-20 -mt-12 mx-4 sm:mx-8 lg:mx-auto max-w-7xl rounded-2xl shadow-2xl backdrop-blur-lg">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 px-8">
        {features.map((feature, index) => (
          <div key={index} className="flex items-center space-x-5 text-white group cursor-pointer">
            <div className="bg-white/10 p-4 rounded-full group-hover:bg-white/20 group-hover:scale-110 transition-all shadow-inner">
              {feature.icon}
            </div>
            <div>
              <h3 className="font-heading font-bold text-lg leading-snug tracking-wide">{feature.title}</h3>
              <p className="text-premium-teal-light font-medium text-sm mt-0.5">{feature.description}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

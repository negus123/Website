import React from 'react';
import { useIsMobile } from '../../hooks/useIsMobile';
import { motion } from 'motion/react';
import { 
  Smile, AlignCenter, Sparkles, Syringe, 
  Baby, AlertCircle, ShieldPlus, Activity, 
  ArrowRight, Search, FileHeart, Droplet
} from 'lucide-react';

const services = [
  { icon: <ShieldPlus />, title: "Dental Implants", desc: "Restore your confidence with permanent, natural-looking tooth replacements." },
  { icon: <Activity />, title: "Root Canal Treatment", desc: "Save infected teeth comfortably with advanced painless root canal treatment." },
  { icon: <AlignCenter />, title: "Braces & Aligners", desc: "Straighten your teeth effectively with modern traditional braces and clear aligners." },
  { icon: <Sparkles />, title: "Teeth Whitening", desc: "Achieve a dazzling smile in a single visit with professional grade whitening." },
  { icon: <Smile />, title: "Smile Makeovers", desc: "Transform your appearance completely with customized cosmetic treatments." },
  { icon: <Activity />, title: "Crowns & Bridges", desc: "Restore the shape, size, and strength of damaged or missing teeth." },
  { icon: <ShieldPlus />, title: "Preventive Dentistry", desc: "Maintain your oral health with regular check-ups, cleaning and preventive care." },
  { icon: <Smile />, title: "General Dentistry", desc: "Comprehensive care for all your daily dental needs and cavity treatments." }
];

export default function Services() {
  const isMobile = useIsMobile();
  return (
    <section id="services" className="py-24 bg-soft-gray relative">
      <div className="absolute top-0 right-0 w-[400px] h-[400px] bg-medical-blue/5 rounded-full blur-[100px] pointer-events-none -translate-y-1/2"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-sm font-bold text-premium-teal uppercase tracking-wider mb-3">Our Expertise</h2>
          <h3 className="text-3xl md:text-5xl font-heading font-extrabold text-gray-900 mb-6 leading-tight">
            Our Advanced Services
          </h3>
          <p className="text-gray-600 text-lg leading-relaxed">
            We offer a comprehensive spectrum of dental care under one roof, utilizing advanced technology to guarantee optimal results and a comfortable experience.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
          {services.map((service, index) => (
            <motion.div 
              key={index}
              initial={{ opacity: 0, y: isMobile ? 10 : 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 1, delay: index * 0.1, ease: [0.22, 1, 0.36, 1] }}
              className="bg-white p-6 sm:p-8 rounded-3xl shadow-[0_4px_20px_rgba(0,0,0,0.03)] hover:shadow-[0_10px_40px_rgba(10,74,124,0.08)] transition-all duration-300 group border border-gray-100/60"
            >
              <div className="w-16 h-16 bg-medical-blue/5 rounded-2xl flex items-center justify-center text-medical-blue mb-6 group-hover:bg-medical-blue group-hover:text-white transition-colors duration-300 shadow-inner">
                {React.cloneElement(service.icon as React.ReactElement, { className: "w-8 h-8" })}
              </div>
              <h4 className="text-xl font-heading font-bold text-gray-900 mb-3 tracking-wide">{service.title}</h4>
              <p className="text-gray-600 font-medium leading-relaxed mb-8">{service.desc}</p>
              
              <a href="#appointment" className="inline-flex items-center text-sm font-bold text-premium-teal group-hover:text-medical-blue transition-colors">
                Book Treatment
                <ArrowRight className="w-4 h-4 ml-2 transform group-hover:translate-x-2 transition-transform duration-300" />
              </a>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

import React from 'react';
import { Facebook, Instagram, Twitter, MapPin, Phone, Mail } from 'lucide-react';
import { Logo } from '../ui/Logo';
import { clinicData } from '../../config/clinic-data';

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-white pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12 border-b border-gray-800 pb-12">
          
          {/* Brand */}
          <div>
            <div className="flex items-center gap-3 mb-4">
              <Logo className="w-10 h-10" />
              <div className="flex flex-col">
                <span className="text-2xl font-heading font-bold text-white leading-none">{clinicData.shortName}</span>
                <span className="text-xs text-premium-teal-light font-medium mt-1 uppercase tracking-wider">Dental Clinic</span>
              </div>
            </div>
            <p className="text-gray-400 text-sm leading-relaxed mb-6">
              Delivering advanced, painless, and premium dental care in {clinicData.locationName}. Your health is our priority.
            </p>
            <div className="flex space-x-4">
              <a href={clinicData.socials.facebook} className="w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center text-gray-400 hover:bg-medical-blue hover:text-white transition-colors">
                <Facebook className="w-5 h-5" />
              </a>
              <a href={clinicData.socials.instagram} className="w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center text-gray-400 hover:bg-medical-blue hover:text-white transition-colors">
                <Instagram className="w-5 h-5" />
              </a>
              <a href={clinicData.socials.twitter} className="w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center text-gray-400 hover:bg-medical-blue hover:text-white transition-colors">
                <Twitter className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-heading font-semibold text-lg mb-6">Quick Links</h4>
            <ul className="space-y-3">
              <li><a href="#about" className="text-gray-400 hover:text-white text-sm transition-colors">About Us</a></li>
              <li><a href="#gallery" className="text-gray-400 hover:text-white text-sm transition-colors">Smile Gallery</a></li>
              <li><a href="#testimonials" className="text-gray-400 hover:text-white text-sm transition-colors">Patient Reviews</a></li>
              <li><a href="#faq" className="text-gray-400 hover:text-white text-sm transition-colors">FAQs</a></li>
              <li><a href="#appointment" className="text-medical-blue-light hover:text-white text-sm font-medium transition-colors">Book Appointment</a></li>
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="font-heading font-semibold text-lg mb-6">Services</h4>
            <ul className="space-y-3">
              <li><a href="#services" className="text-gray-400 hover:text-white text-sm transition-colors">Dental Implants</a></li>
              <li><a href="#services" className="text-gray-400 hover:text-white text-sm transition-colors">Braces & Aligners</a></li>
              <li><a href="#services" className="text-gray-400 hover:text-white text-sm transition-colors">Cosmetic Dentistry</a></li>
              <li><a href="#services" className="text-gray-400 hover:text-white text-sm transition-colors">Preventive Dentistry</a></li>
              <li><a href="#services" className="text-gray-400 hover:text-white text-sm transition-colors">General Dentistry</a></li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-heading font-semibold text-lg mb-6">Contact Us</h4>
            <ul className="space-y-4">
              <li className="flex items-start">
                <MapPin className="w-5 h-5 text-premium-teal-light mr-3 flex-shrink-0 mt-0.5" />
                <span className="text-gray-400 text-sm">{clinicData.fullAddress}</span>
              </li>
              <li className="flex items-center">
                <Phone className="w-5 h-5 text-premium-teal-light mr-3 flex-shrink-0" />
                <a href={`tel:${clinicData.phone.replace(/[\s+]/g, '')}`} className="text-gray-400 hover:text-white text-sm transition-colors">{clinicData.phone}</a>
              </li>
              <li className="flex items-center">
                <Mail className="w-5 h-5 text-premium-teal-light mr-3 flex-shrink-0" />
                <a href={`mailto:${clinicData.email}`} className="text-gray-400 hover:text-white text-sm transition-colors">{clinicData.email}</a>
              </li>
            </ul>
          </div>

        </div>

        <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
          <p className="text-gray-500 text-sm">
            © {new Date().getFullYear()} {clinicData.fullName}. All Rights Reserved.
          </p>
          <div className="flex space-x-6 text-sm">
            <a href="#" className="text-gray-500 hover:text-gray-300">Privacy Policy</a>
            <a href="#" className="text-gray-500 hover:text-gray-300">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
}

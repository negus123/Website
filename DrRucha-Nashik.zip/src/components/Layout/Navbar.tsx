import React, { useState, useEffect } from 'react';
import { Menu, X, Phone, Calendar, MapPin, MessageCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Logo } from '../ui/Logo';
import { clinicData } from '../../config/clinic-data';

export default function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('home');

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
      
      // Active section highlighting
      const sections = ['home', 'about', 'doctor', 'services', 'gallery', 'testimonials', 'faq'];
      const scrollPosition = window.scrollY + 100;

      for (const section of sections) {
        const element = document.getElementById(section);
        if (element && element.offsetTop <= scrollPosition && (element.offsetTop + element.offsetHeight) > scrollPosition) {
          setActiveSection(section);
        }
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Home', href: '#home', id: 'home' },
    { name: 'About', href: '#about', id: 'about' },
    { name: 'Services', href: '#services', id: 'services' },
    { name: 'Smile Gallery', href: '#gallery', id: 'gallery' },
    { name: 'Patient Reviews', href: '#testimonials', id: 'testimonials' },
    { name: 'FAQ', href: '#faq', id: 'faq' },
  ];

  return (
    <header className={`fixed top-0 w-full z-50 transition-all duration-300 ${isScrolled ? 'bg-white shadow-md py-2' : 'bg-white/95 backdrop-blur-md py-4 border-b border-gray-100/50'}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center">
          {/* Logo */}
          <a href="#home" className="flex items-center gap-3 group">
            <Logo className="w-10 h-10" />
            <div className="flex flex-col">
              <span className="text-2xl font-heading font-bold text-medical-blue leading-none group-hover:text-medical-blue-light transition-colors">{clinicData.shortName}</span>
              <span className="text-[10px] text-premium-teal font-medium mt-1 uppercase tracking-widest">Dental Clinic</span>
            </div>
          </a>

          {/* Desktop Nav */}
          <nav className="hidden lg:flex items-center space-x-1">
            {navLinks.map((link) => (
              <a 
                key={link.name} 
                href={link.href}
                className={`relative px-4 py-2 font-medium transition-colors text-sm rounded-full ${
                  activeSection === link.id 
                    ? 'text-medical-blue bg-medical-blue/5' 
                    : 'text-gray-600 hover:text-medical-blue hover:bg-gray-50'
                }`}
              >
                {link.name}
              </a>
            ))}
          </nav>

          {/* Desktop Actions */}
          <div className="hidden lg:flex items-center space-x-4">
            <a href={`tel:${clinicData.phone.replace(/[\s+]/g, '')}`} className="flex items-center text-medical-blue font-semibold hover:text-medical-blue-light transition-colors group">
              <div className="w-8 h-8 rounded-full bg-medical-blue/10 flex items-center justify-center mr-2 group-hover:bg-medical-blue/20 transition-colors">
                <Phone className="w-4 h-4" />
              </div>
              <span className="text-sm">{clinicData.phone}</span>
            </a>
            <a href="#appointment" className="bg-medical-blue hover:bg-medical-blue-dark text-white px-6 py-2.5 rounded-full font-semibold transition-all shadow-md hover:shadow-lg text-sm inline-flex items-center transform hover:-translate-y-0.5">
              <Calendar className="w-4 h-4 mr-2" />
              Book Visit
            </a>
          </div>

          {/* Mobile Menu Toggle */}
          <button 
            className="lg:hidden p-2 text-gray-900 hover:text-medical-blue transition-colors rounded-full hover:bg-gray-50"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            aria-label="Toggle menu"
          >
            {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu Content */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="lg:hidden bg-white border-t border-gray-100 shadow-xl overflow-hidden"
          >
            <div className="px-4 py-6 space-y-2">
              {navLinks.map((link) => (
                <a
                  key={link.name}
                  href={link.href}
                  onClick={() => setIsMobileMenuOpen(false)}
                  className={`block px-4 py-3 rounded-xl font-medium transition-colors ${
                    activeSection === link.id 
                      ? 'text-medical-blue bg-medical-blue/5' 
                      : 'text-gray-700 hover:text-medical-blue hover:bg-gray-50'
                  }`}
                >
                  {link.name}
                </a>
              ))}
              <div className="pt-6 mt-4 border-t border-gray-100 space-y-4 px-2">
                <a href={`tel:${clinicData.phone.replace(/[\s+]/g, '')}`} className="flex items-center text-gray-900 font-semibold p-3 rounded-xl hover:bg-gray-50 transition-colors">
                  <div className="w-10 h-10 rounded-full bg-medical-blue/10 flex items-center justify-center mr-3">
                    <Phone className="w-5 h-5 text-medical-blue" />
                  </div>
                  <span>{clinicData.phone}</span>
                </a>
                <a 
                  href={`https://wa.me/${clinicData.whatsappNumber}?text=Hello%20I%20would%20like%20to%20book%20an%20appointment`}
                  target="_blank" rel="noopener noreferrer" 
                  className="flex items-center text-gray-900 font-semibold p-3 rounded-xl hover:bg-gray-50 transition-colors"
                >
                  <div className="w-10 h-10 rounded-full bg-green-50 flex items-center justify-center mr-3">
                    <MessageCircle className="w-5 h-5 text-green-500" />
                  </div>
                  <span>WhatsApp Us</span>
                </a>
                <a href="#appointment" onClick={() => setIsMobileMenuOpen(false)} className="w-full bg-medical-blue text-white text-center py-4 rounded-xl font-bold inline-block mt-4 shadow-md active:scale-95 transition-transform">
                  Book Appointment
                </a>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}

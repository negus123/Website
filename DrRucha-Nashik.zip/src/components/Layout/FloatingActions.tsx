import React, { useState, useEffect } from 'react';
import { PhoneCall, CalendarDays, MessageCircle, ArrowUp, MapPin } from 'lucide-react';
import { AnimatedCounter } from '../ui/AnimatedCounter';
import { clinicData } from '../../config/clinic-data';

export default function FloatingActions() {
  const [showBackToTop, setShowBackToTop] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setShowBackToTop(window.scrollY > 500);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <>
      {/* Floating Review Badge */}
      <a href={`https://www.google.com/search?q=${clinicData.googleMapsQuery}#lrd=0x0:0x0,3,,,`} target="_blank" rel="noopener noreferrer" className="fixed top-24 right-4 z-40 hidden md:flex items-center space-x-2 bg-white px-3 py-2 rounded-full shadow-[0_4px_15px_rgba(0,0,0,0.08)] border border-gray-100 group cursor-pointer hover:shadow-[0_8px_25px_rgba(0,0,0,0.12)] hover:scale-105 transition-all">
        <div className="bg-white p-1 rounded-full shadow-sm border border-gray-50 flex items-center justify-center w-6 h-6">
          <svg viewBox="0 0 24 24" className="w-4 h-4" xmlns="http://www.w3.org/2000/svg">
            <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
            <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
            <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
            <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
          </svg>
        </div>
        <div className="flex flex-col pr-1">
          <span className="text-[11px] font-bold text-gray-900 leading-none"><AnimatedCounter end={5.0} decimals={1} />/5 Rating</span>
          <span className="text-[9px] text-gray-500 font-medium leading-none mt-0.5"><AnimatedCounter end={194} suffix="+" /> Reviews</span>
        </div>
      </a>

      {/* Bottom Sticky Action Bar (Mobile Only) */}
      <div className="fixed bottom-0 left-0 right-0 z-[9999] md:hidden bg-white/85 backdrop-blur-xl rounded-t-3xl shadow-[0_-10px_40px_rgba(0,0,0,0.1)] border-t border-white/60 pb-[env(safe-area-inset-bottom)]">
        <div className="flex items-center justify-around px-2 py-3">
          <a href={`tel:${clinicData.phone.replace(/[\s+]/g, '')}`} className="flex flex-col items-center justify-center space-y-1.5 p-2 text-gray-600 hover:text-medical-blue transition-colors active:scale-95">
            <div className="bg-blue-50 text-medical-blue p-2.5 rounded-full">
              <PhoneCall className="w-5 h-5" />
            </div>
            <span className="text-[10px] font-bold tracking-wide">Call</span>
          </a>
          <a href={`https://wa.me/${clinicData.whatsappNumber}?text=Hello%20I%20would%20like%20to%20book%20an%20appointment`} className="flex flex-col items-center justify-center space-y-1.5 p-2 text-gray-600 hover:text-green-600 transition-colors active:scale-95">
            <div className="bg-green-50 text-green-600 p-2.5 rounded-full">
              <MessageCircle className="w-5 h-5" />
            </div>
            <span className="text-[10px] font-bold tracking-wide">WhatsApp</span>
          </a>
          <a href="#appointment" className="flex flex-col items-center justify-center space-y-1.5 p-2 text-gray-600 hover:text-medical-blue transition-colors active:scale-95" onClick={(e) => {
            e.preventDefault();
            const el = document.getElementById('appointment');
            if (el) {
              const yOffset = -80; 
              const y = el.getBoundingClientRect().top + window.pageYOffset + yOffset;
              window.scrollTo({top: y, behavior: 'smooth'});
            }
          }}>
            <div className="bg-blue-50 text-medical-blue p-2.5 rounded-full">
              <CalendarDays className="w-5 h-5" />
            </div>
            <span className="text-[10px] font-bold tracking-wide">Book</span>
          </a>
          <a href={`https://www.google.com/maps/search/?api=1&query=${clinicData.googleMapsQuery}`} target="_blank" rel="noopener noreferrer" className="flex flex-col items-center justify-center space-y-1.5 p-2 text-gray-600 hover:text-medical-blue transition-colors active:scale-95">
            <div className="bg-blue-50 text-medical-blue p-2.5 rounded-full">
              <MapPin className="w-5 h-5" />
            </div>
            <span className="text-[10px] font-bold tracking-wide">Directions</span>
          </a>
        </div>
      </div>

      {/* Floating WhatsApp, Book Buttons, Back to Top (Desktop/Tablet) */}
      <div className="fixed bottom-6 right-6 z-40 hidden md:flex flex-col space-y-4">
        {showBackToTop && (
          <button 
            onClick={scrollToTop}
            className="w-14 h-14 bg-white text-gray-600 rounded-full flex justify-center items-center shadow-lg hover:shadow-xl hover:-translate-y-1 hover:text-medical-blue transition-all border border-gray-100 mb-2"
          >
            <ArrowUp className="w-6 h-6" />
          </button>
        )}
        <a 
          href="#appointment" 
          className="bg-medical-blue text-white rounded-full p-4 shadow-lg hover:shadow-xl hover:scale-110 transition-all group relative flex items-center justify-center"
        >
          <CalendarDays className="w-6 h-6" />
          <span className="absolute right-full mr-4 bg-gray-900 text-white text-xs font-semibold px-3 py-1.5 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none">
            Book Appointment
          </span>
        </a>
        <a 
          href={`https://wa.me/${clinicData.whatsappNumber}?text=Hello%20I%20would%20like%20to%20book%20an%20appointment`} 
          target="_blank" rel="noopener noreferrer"
          className="bg-green-500 text-white rounded-full p-4 shadow-lg hover:shadow-xl hover:scale-110 transition-all group relative flex items-center justify-center"
        >
          <MessageCircle className="w-6 h-6" />
          <span className="absolute right-full mr-4 bg-gray-900 text-white text-xs font-semibold px-3 py-1.5 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none">
            Chat on WhatsApp
          </span>
        </a>
      </div>
    </>
  );
}
